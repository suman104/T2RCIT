package com.tcs.T2RCIT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T2RcitApplication {

	public static void main(String[] args) {
		SpringApplication.run(T2RcitApplication.class, args);
	}

}
